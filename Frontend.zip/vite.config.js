import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

// https://vite.dev/config/
export default defineConfig({
  theme: {
    extend: {
      colors: {
        'primary': 'red', // Example primary color (OrangeRed)
      },
    },
  },
  plugins: [react(),tailwindcss(),],
})
